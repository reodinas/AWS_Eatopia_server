class Config :
    HOST = 'yh-db.cdtkthbhsama.ap-northeast-2.rds.amazonaws.com'
    DATABASE = 'Eatopia_DB'
    DB_USER = 'Eatopia_DB_user'
    DB_PASSWORD = 'dltxhvldk1234db'
    SALT = 'friday'

    # JWT 관련 변수 셋팅
    JWT_SECRET_KEY = 'moviemovie'
    JWT_ACCESS_TOKEN_EXPIRES = False 
    
    PROPAGATE_EXCEPTIONS = True # JWT 에러메시지를 명시함

    # AWS 관련 키
    ACCESS_KEY = 'AKIA52FDGCHI6AXKHH6V'
    SECRET_ACCESS = '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'

    # S3 버킷
    S3_BUCKET = 'reodinas-eatopia'
    # S3 Location
    S3_LOCATION = 'https://reodinas-eatopia.s3.ap-northeast-2.amazonaws.com/'

    COLLECTION_ID = 'Eatopia'